// script.js
// Digital clock with date, 12/24-hour toggle and theme toggle.
// Stores preferences in localStorage so choices persist.

const clockEl = document.getElementById('clock');
const dateEl = document.getElementById('date');
const btnFormat = document.getElementById('toggle-format');
const btnTheme = document.getElementById('toggle-theme');

let use24Hour = JSON.parse(localStorage.getItem('dc_use24')) ?? false;
let theme = localStorage.getItem('dc_theme') || 'dark';

// apply saved theme
document.documentElement.setAttribute('data-theme', theme);
btnTheme.textContent = theme === 'light' ? 'Dark theme' : 'Light theme';
btnFormat.textContent = use24Hour ? 'Switch to 12-hour' : 'Switch to 24-hour';

// pad helper
const pad = (n) => String(n).padStart(2, '0');

function formatTime(now) {
  let hours = now.getHours();
  let minutes = now.getMinutes();
  let seconds = now.getSeconds();
  const dayPeriod = hours >= 12 ? 'PM' : 'AM';

  if (!use24Hour) {
    hours = hours % 12;
    hours = hours === 0 ? 12 : hours;
  }

  const hh = pad(hours);
  const mm = pad(minutes);
  const ss = pad(seconds);

  return use24Hour ? `${hh}:${mm}:${ss}` : `${hh}:${mm}:${ss} ${dayPeriod}`;
}

function formatDate(now) {
  // e.g., Saturday, Sep 20, 2025
  const opts = { weekday: 'long', month: 'short', day: 'numeric', year: 'numeric' };
  return now.toLocaleDateString(undefined, opts);
}

function updateClock() {
  const now = new Date();
  clockEl.textContent = formatTime(now);
  dateEl.textContent = formatDate(now);
}

// control handlers
btnFormat.addEventListener('click', () => {
  use24Hour = !use24Hour;
  localStorage.setItem('dc_use24', JSON.stringify(use24Hour));
  btnFormat.textContent = use24Hour ? 'Switch to 12-hour' : 'Switch to 24-hour';
  updateClock();
});

btnTheme.addEventListener('click', () => {
  theme = theme === 'light' ? 'dark' : 'light';
  document.documentElement.setAttribute('data-theme', theme);
  localStorage.setItem('dc_theme', theme);
  btnTheme.textContent = theme === 'light' ? 'Dark theme' : 'Light theme';
});

// initialize
updateClock();
setInterval(updateClock, 1000); // update every second
